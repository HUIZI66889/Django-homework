from django import forms
from .models import Child, SwimClass

class ChildForm(forms.ModelForm):
    class Meta:
        model = Child
        fields = ['name', 'age', 'parent']

class SwimClassForm(forms.ModelForm):
    class Meta:
        model = SwimClass
        fields = ['instructor', 'min_age', 'max_age', 'children']
        widgets = {
            'children': forms.CheckboxSelectMultiple()
        }
