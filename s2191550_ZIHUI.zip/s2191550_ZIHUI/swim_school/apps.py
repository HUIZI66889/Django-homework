from django.apps import AppConfig


class SwimSchoolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'swim_school'
