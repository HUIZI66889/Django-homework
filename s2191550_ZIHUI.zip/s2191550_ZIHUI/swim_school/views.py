# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Profile, Child, SwimClass, Attendance, Progress
from django.views import View
from .forms import ChildForm, SwimClassForm


def main_page(request):
    return render(request, 'swim_school/main_page.html')

@login_required(login_url='login')
def create_child_profile(request):
    if request.method == 'POST':
        child_name = request.POST['child_name']
        age = request.POST['age']
        parent = request.user
        child = Child.objects.create(name=child_name, age=age, parent=parent)
        return redirect('child_profile', child_id=child.id)
    return render(request, 'swim_school/create_child_profile.html')

@login_required(login_url='login')
def child_profile(request,child_id ):
    child = Child.objects.get(id=child_id)
    return render(request, 'swim_school/child_profile.html', {'child': child})

@login_required(login_url='login')
def search_swim_classes(request):
    if request.method == 'POST':
        age = request.POST['age']
        swim_classes = SwimClass.objects.filter(min_age__lte=age, max_age__gte=age)
        return render(request, 'swim_school/swim_classes.html', {'swim_classes': swim_classes})
    return render(request, 'swim_school/search_swim_classes.html')

@login_required(login_url='login')
def register_swim_class(request, class_id):
    swim_class = SwimClass.objects.get(id=class_id)
    child = Child.objects.get(id=request.POST['child_id'])
    swim_class.children.add(child)
    return redirect('child_profile', child_id=child.id)

@login_required(login_url='login')
def view_class_schedule(request):
    parent = request.user
    children = Child.objects.filter(parent=parent)
    return render(request, 'swim_school/class_schedule.html', {'children': children})

@login_required(login_url='login')
def create_instructor_profile(request):
    if request.method == 'POST':
        instructor_name = request.POST['instructor_name']
        instructor = User.objects.create_user(username=instructor_name)
        profile = Profile.objects.create(user=instructor)
        return redirect('manage_swim_classes')
    return render(request, 'swim_school/create_instructor_profile.html')

@login_required(login_url='login')
def manage_swim_classes(request):
    instructor = request.user
    swim_classes = SwimClass.objects.filter(instructor=instructor)
    return render(request, 'swim_school/manage_swim_classes.html', {'swim_classes': swim_classes})

@login_required(login_url='login')
def mark_attendance(request, class_id):
    swim_class = SwimClass.objects.get(id=class_id)
    children = swim_class.children.all()
    if request.method == 'POST':
        for child in children:
            attendance_status = request.POST.get(str(child.id))
            Attendance.objects.create(child=child, swim_class=swim_class, status=attendance_status)
        return redirect('manage_swim_classes')
    return render(request, 'swim_school/mark_attendance.html', {'children': children, 'swim_class': swim_class})

@login_required(login_url='login')
def update_progress(request, child_id):
    child = Child.objects.get(id=child_id)
    swim_class = child.swimclass_set.first()
    if request.method == 'POST':
        progress = request.POST['progress']
        Progress.objects.create(child=child, swim_class=swim_class, progress=progress)
        return redirect('child_profile', child_id=child.id)
    return render(request, 'swim_school/update_progress.html', {'child': child})

class AddChildFormView(View):
    def get(self, request):
        form = ChildForm()
        return render(request, 'swim_school/add_child.html', {'form': form})

    def post(self, request):
        form = ChildForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('main_page')
        return render(request, 'swim_school/add_child.html', {'form': form})


class AddSwimClassFormView(View):
    def get(self, request):
        form = SwimClassForm()
        return render(request, 'swim_school/add_swim_class.html', {'form': form})

    def post(self, request):
        form = SwimClassForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('main_page')
        return render(request, 'swim_school/add_swim_class.html', {'form': form})
