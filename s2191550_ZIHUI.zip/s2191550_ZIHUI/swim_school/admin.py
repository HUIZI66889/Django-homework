from django.contrib import admin

# Register your models here.
from .models import Profile
from .models import Child
from .models import SwimClass
from .models import Attendance
from .models import Progress


admin.site.register(Profile)
admin.site.register(Child)
admin.site.register(SwimClass)
admin.site.register(Attendance)
admin.site.register(Progress)