from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

class Child(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    parent = models.ForeignKey(User, on_delete=models.CASCADE)

class SwimClass(models.Model):
    instructor = models.ForeignKey(User, on_delete=models.CASCADE)
    min_age = models.PositiveIntegerField()
    max_age = models.PositiveIntegerField()
    children = models.ManyToManyField(Child)

class Attendance(models.Model):
    child = models.ForeignKey(Child, on_delete=models.CASCADE)
    swim_class = models.ForeignKey(SwimClass, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=[('Present', 'Present'), ('Absent', 'Absent')])

class Progress(models.Model):
    child = models.ForeignKey(Child, on_delete=models.CASCADE)
    swim_class = models.ForeignKey(SwimClass, on_delete=models.CASCADE)
    progress = models.CharField(max_length=100)


